﻿using UnityEngine;
using System.Collections;
using UnityEngine.Advertisements;
using UnityEngine.UI;

public class UnityAdsIntegration : MonoBehaviour
{

	[SerializeField] private string androidGameId = "18658"; //ID for testing
	[SerializeField] private string iOSGameId = "18658"; //ID for testing
	public string zoneId = "rewardedVideo";

	[Space(3)]
	[SerializeField] bool enableTestMode;

	public Text status;

	public Text[] coinTexts;

	public int rewardedCoins = 1000;

	void Start ()
	{
		string gameId = null;
		#if UNITY_ANDROID
		gameId = androidGameId;
		#else
		gameId = iOSGameId;
		#endif
		if(!Advertisement.isInitialized) {
			Advertisement.Initialize(gameId, enableTestMode);

		} 
	}

	// Call this from UI.Button to show ads    
	public void Show()
	{

		ShowOptions options = new ShowOptions();

		options.resultCallback = HandleShowResult;
			
		Advertisement.Show (zoneId, options);

	}

	private void HandleShowResult (ShowResult result)
	{
		switch (result)
		{
		case ShowResult.Finished:
			PlayerPrefs.SetInt ("Coins", PlayerPrefs.GetInt ("Coins") + rewardedCoins);
			for(int a = 0;a<coinTexts.Length;a++)
				coinTexts[a].text = "Total Coins : " + PlayerPrefs.GetInt ("Coins").ToString ();
			if(status)
				status.text = rewardedCoins+" Coins Rewarded";
			break;
		case ShowResult.Skipped:
			if(status)
				status.text = "Video was skipped";
			break;
		case ShowResult.Failed:
			if(status)
				status.text = "Unknown error";
			break;
		}
	}
}